from flask import Flask,render_template,make_response,session,flash,get_flashed_messages,request,send_from_directory,jsonify
from flask_wtf import Form
from wtforms import StringField,PasswordField, validators
from wtforms.validators import DataRequired
from PIL import Image, ImageDraw, ImageFont ,ImageFilter
from io import BytesIO
import mysql.connector
import random
import string
import time
import json
import os

app = Flask(__name__)
app.secret_key='12345678'

#session配置
#app.config['SECRET_KEY']=os.urandom(24)
#app.config['PERMANENT_SESSION_LIFETIME']=timedelta(hours=48)

#上传配置
app.config['ALLOWED_EXTENSIONS'] = set(['mp4','png','jpg'])
app.config['UPLOAD_PATH'] = 'upload'

#测试环境数据库
mydb = mysql.connector.connect(
    host="is1701.top",
    user="python_dev",
    passwd="ir4DyFBKLkpckWsi",
    database="python_dev",
    buffered = True
)


#登录表单类
class LoginForm(Form):
    user =StringField('username',validators=[DataRequired()])
    password = PasswordField('password', validators=[DataRequired()])
    verify_code = StringField('VerifyCode', validators=[DataRequired()])

#注册表单类
class RegisterForm(Form):
    username = StringField('用户名', validators=[DataRequired()])
    phone = StringField('手机号', validators=[DataRequired()])
    email = StringField('email', validators=[DataRequired()])
    password = PasswordField('密码', [DataRequired()])
    confirm = PasswordField('重复密码',validators=[
        validators.DataRequired(),
        validators.EqualTo('password', message='两次输入的密码要一致')
    ])
    verify_code = StringField('验证码', validators=[DataRequired()])


@app.route("/")
def hello():
    return "Hello world"

#登录功能
@app.route("/login",methods=('GET','POST'))
def login():
    form = LoginForm()
    if form.validate_on_submit():

        mycursor = mydb.cursor(buffered=True)
        sql = "SELECT password FROM user WHERE username = %s AND password =%s"
        na = (form.user.data, form.password.data)
        mycursor.execute(sql, na)
        if session.get('image').lower() != form.verify_code.data.lower():
            flash('验证码错误')
            return render_template('/login.html', form=form)

        if mycursor.rowcount==1:
            session['username'] = form.user.data
            return "登陆成功"
        else:
            return "登陆失败"
    return render_template('login.html',form=form)

#注销功能
@app.route('/logout')
def logout():
    # 验证登录情况
    if not session.get('username'):
        return jsonify({'code': -1,'msg': 'please sign in first'})
    # remove the username from the session if it's there
    session.clear()
    return jsonify({'code': 0, 'msg': 'success'})

#注册功能
@app.route("/register",methods=('GET','POST'))
def register():
    form=RegisterForm()
    mycursor = mydb.cursor()
    if form.validate_on_submit():
        sql = "INSERT INTO user (username,password,phone,email) VALUES (%s,%s,%s,%s)"
        val = (form.username.data,form.password.data,form.phone.data,form.email.data)
        mycursor.execute(sql, val)
        mydb.commit()
        if mycursor.rowcount==1:
            return "注册成功"
        else:
            return "注册失败"
    return render_template('register.html',form=form)

#生成验证码功能
def rndColor():
    # 随机颜色
    return (random.randint(32, 127), random.randint(32, 127), random.randint(32, 127))


def gene_text():
    # 生成4位验证码
    return ''.join(random.sample(string.ascii_letters + string.digits, 4))


def draw_lines(draw, num, width, height):
    # 划线
    for num in range(num):
        x1 = random.randint(0, width / 2)
        y1 = random.randint(0, height / 2)
        x2 = random.randint(0, width)
        y2 = random.randint(height / 2, height)
        draw.line(((x1, y1), (x2, y2)), fill='black', width=1)


def get_verify_code():
    # 生成验证码图形
    code = gene_text()
    # 图片大小120×50
    width, height = 120, 50
    # 新图片对象
    im = Image.new('RGB', (width, height), 'white')
    # 字体
    font = ImageFont.truetype('app/static/arial.ttf', 40)
    # draw对象
    draw = ImageDraw.Draw(im)
    str = ''
    # 绘制字符串
    for item in range(4):
        draw.text((5 + random.randint(-3, 3) + 23 * item, 5 + random.randint(-3, 3)),
                  text=code[item], fill=rndColor(), font=font)
    # 划线
    draw_lines(draw, 2, width, height)
    # 高斯模糊
    im = im.filter(ImageFilter.GaussianBlur(radius=1.5))
    return im, code


@ app.route("/code", methods=('GET', 'POST'))
def get_code():
    image, code = get_verify_code()
    # 图片以二进制形式写入
    buf = BytesIO()
    image.save(buf, 'jpeg')
    buf_str = buf.getvalue()
    # 把buf_str作为response返回前端，并设置首部字段
    response = make_response(buf_str)
    response.headers['Content-Type'] = 'image/gif'
    # 将验证码字符串储存在session中
    session['image'] = code
    session.permanent=True
    return response


#检查上传文件格式
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# 文件上传接口
@app.route('/upload', methods=['GET','POST'])
def upload_file():
    # 验证登录情况
    if not session.get('username'):
        return jsonify({'code': -1,'msg': 'please sign in first'})

    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            return jsonify({'code': -1, 'filename': '', 'msg': 'No file part'})
        file = request.files['file']
        # if user does not select file, browser also submit a empty part without filename
        if file.filename == '':
            return jsonify({'code': -1, 'filename': '', 'msg': 'No selected file'})
        else:
            try:
                if file and allowed_file(file.filename):
                    # origin_file_name = file.filename
                    # filename = secure_filename(file.filename)
                    # filename = origin_file_name

                    #如果上传目录不存在就新建
                    if os.path.exists(app.config['UPLOAD_PATH']):
                        pass
                    else:
                        os.makedirs(app.config['UPLOAD_PATH'])

                    #存储文件
                    file.save(os.path.join(app.config['UPLOAD_PATH'], file.filename))

                    #获取当前时间
                    uploadtime=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

                    #在数据库插入相关信息
                    mycursor = mydb.cursor()
                    sql = "INSERT INTO videolist (name,time) VALUES (%s,%s)"
                    value = (file.filename,uploadtime)
                    mycursor.execute(sql,value)
                    mydb.commit()

                    return jsonify({'code': 0, 'filename': uploadtime, 'msg': 'success'})
                else:
                    return jsonify({'code': -1, 'filename': file.filename, 'msg': 'File not allowed'})
            except Exception as e:
                return jsonify({'code': -1, 'filename': uploadtime, 'msg': 'Error occurred'})
    else:
      return render_template('upload.html')


#删除文件接口 接口参数：filename:需要删除的文件名
@app.route('/delete', methods=['GET'])
def delete_file():
    # 验证登录情况
    if not session.get('username'):
        return jsonify({'code': -1,'msg': 'please sign in first'})

    if request.method == 'GET':
        filename = request.args.get('filename')
        try:
            fullfile = os.path.join(app.config['UPLOAD_PATH'], filename)

            if os.path.exists(fullfile):
                os.remove(fullfile)

                #删除数据库中相关数据
                mycursor = mydb.cursor()
                sql = "DELETE FROM videolist WHERE name = %s"
                val = (str(filename),)
                mycursor.execute(sql, val)
                mydb.commit()

                return jsonify({'code': 0, 'msg': 'success'})
            else:
                return jsonify({'code': -1, 'msg': 'File not exist'})

        except Exception as e:
            return jsonify({'code': -1, 'msg': 'File deleted error'})
    else:
        return jsonify({'code': -1, 'msg': 'Method not allowed'})

# 文件下载 访问路径示例: /files/1.png
@app.route('/files/<string:filename>', methods=['GET'])
def send_html(filename):
    # 验证登录情况
    if not session.get('username'):
        return jsonify({'code': -1,'msg': 'please sign in first'})
    return send_from_directory(app.config['UPLOAD_PATH'], filename, as_attachment=True)

@app.route('/api/list', methods=['GET'])
def get_list():
    #验证登录情况
    if not session.get('username'):
        return jsonify({'code': -1,'msg': 'please sign in first'})

    page = request.args.get('page')
    limit = request.args.get('limit')
    mycursor = mydb.cursor()
    sql = "SELECT * FROM videolist LIMIT %s,%s"
    val = (int(limit)*(int(page)-1),int(limit))
    mycursor.execute(sql, val)
    result = mycursor.fetchall()

    #pages = monitor_util.get_monitor_flask_sqlalchemy(int(page), int(limit))
    if mycursor.rowcount == 0:
        return jsonify({"code": 0, "msg": "", "count": 0, "data": {}})
    else:
        data = []

        for row in result:
            temp = {}
            temp['id']=row[0]
            temp['name']=row[1]
            temp['time']=row[2]

            data.append(temp)
        result = json.dumps({"code": 0, "msg": "success", "count": mycursor.rowcount, "data": data})
        return result

if __name__ == "__main__":
    app.run(debug=True)
